/* YouTube Ambient Background - content script
 * Draws the playing video into a tiny canvas (a few pixels wide) and shows
 * that canvas scaled up and blurred behind the player. Drawing a video onto
 * a visible canvas needs no pixel read-back, so it is not affected by canvas
 * "tainting". DRM-protected videos (some films/rentals) render black to
 * canvas; in that case we detect it and fall back to the manual colour.
 */
(function () {
  "use strict";
  if (window.__ytAmbientLoaded) return;
  window.__ytAmbientLoaded = true;

  const S = window.YTAmbientSettings;
  let settings = Object.assign({}, S.DEFAULTS);

  const SAMPLE_W = 16;
  const SAMPLE_H = 9;
  const FRAME_INTERVAL = 100; // ms (~10 fps is plenty for a blurred glow)

  let layer = null;       // wrapper positioned behind the player
  let canvas = null;
  let ctx = null;
  let probe = null;       // 1x1 canvas used to detect blocked / black frames
  let probeCtx = null;
  let video = null;
  let timer = null;
  let autoBlocked = false; // true when sampling is impossible (DRM / security error)
  let blackFrames = 0;

  /* ---------- DOM helpers ---------- */
  const $ = (sel, r = document) => r.querySelector(sel);
  const player = () => $("#movie_player");
  const isWatch = () => location.pathname === "/watch";
  const isFullscreen = () => !!document.fullscreenElement;

  function ensureLayer() {
    if (!layer) {
      layer = document.createElement("div");
      layer.id = "yta-layer";
      canvas = document.createElement("canvas");
      canvas.width = SAMPLE_W;
      canvas.height = SAMPLE_H;
      canvas.id = "yta-canvas";
      layer.appendChild(canvas);
      ctx = canvas.getContext("2d", { alpha: false });
      probe = document.createElement("canvas");
      probe.width = probe.height = 1;
      probeCtx = probe.getContext("2d", { willReadFrequently: true });
    }
    placeLayer();
    return layer;
  }

  /* Normal & theater: put the layer just before the player's outer container
   * inside ytd-watch-flexy so it can spread outside the player box.
   * Fullscreen: put it inside #movie_player so it fills the letterbox bars. */
  function placeLayer() {
    if (!layer) return;
    const p = player();
    if (!p) return;
    let host;
    if (isFullscreen()) {
      host = p;
      layer.dataset.mode = "fullscreen";
    } else {
      host = $("ytd-watch-flexy #player-container-outer") ||
             $("ytd-watch-flexy #full-bleed-container") ||
             p.parentElement;
      // in theater mode the player lives in the full-bleed container
      const theater = $("ytd-watch-flexy[theater] #full-bleed-container");
      if (theater && theater.contains(p)) host = theater;
      layer.dataset.mode = "page";
    }
    if (!host) return;
    if (layer.parentElement !== host) host.insertBefore(layer, host.firstChild);
    document.documentElement.classList.toggle("yta-active", settings.enabled && isWatch());
  }

  /* ---------- Styling from settings ---------- */
  function applyStyle() {
    const root = document.documentElement;
    root.style.setProperty("--yta-blur", settings.blur + "px");
    root.style.setProperty("--yta-opacity", String(settings.intensity / 100));
    root.style.setProperty("--yta-spread", (settings.size * 1.2).toFixed(0) + "px");
    root.style.setProperty("--yta-scale", (1 + settings.size / 250).toFixed(3));
    root.style.setProperty("--yta-color", settings.color);
    const manual = settings.mode === "manual" || autoBlocked;
    root.classList.toggle("yta-manual", manual);
    root.classList.toggle("yta-active", settings.enabled && isWatch());
    updatePanelUI();
  }

  /* ---------- Sampling loop ---------- */
  function drawFrame() {
    if (!video || !ctx || video.readyState < 2 || video.videoWidth === 0) return;
    try {
      ctx.drawImage(video, 0, 0, SAMPLE_W, SAMPLE_H);
    } catch (e) {
      setBlocked(true);
      return;
    }
    // Occasionally check if frames come out black while video plays (DRM).
    if (!video.paused && Math.random() < 0.2) checkBlack();
  }

  function checkBlack() {
    try {
      probeCtx.drawImage(canvas, 0, 0, 1, 1);
      const d = probeCtx.getImageData(0, 0, 1, 1).data;
      if (d[0] + d[1] + d[2] < 3) blackFrames++;
      else { blackFrames = 0; if (autoBlocked) setBlocked(false); }
      if (blackFrames > 25) setBlocked(true); // ~12s of pure black while playing
    } catch (e) {
      // Read-back blocked: drawing still works visually, so keep auto mode.
    }
  }

  function setBlocked(v) {
    if (autoBlocked === v) return;
    autoBlocked = v;
    applyStyle();
  }

  function shouldRun() {
    return settings.enabled && settings.mode === "auto" && isWatch() && !document.hidden;
  }

  function start() {
    if (timer || !shouldRun()) return;
    timer = setInterval(() => {
      if (!video || !video.isConnected) video = $("#movie_player video.html5-main-video");
      if (video && (!video.paused || video.seeking)) drawFrame();
    }, FRAME_INTERVAL);
    drawFrame();
  }

  function stop() {
    clearInterval(timer);
    timer = null;
  }

  function refresh() {
    if (!isWatch()) {
      stop();
      document.documentElement.classList.remove("yta-active");
      return;
    }
    video = $("#movie_player video.html5-main-video");
    ensureLayer();
    injectPanel();
    applyStyle();
    if (shouldRun()) { start(); setTimeout(drawFrame, 300); } else stop();
  }

  /* ---------- In-player settings panel ---------- */
  let panel = null, btn = null;

  function injectPanel() {
    const p = player();
    const gear = p && $(".ytp-right-controls .ytp-settings-button", p);
    if (!gear) return;
    if (!btn || !btn.isConnected) {
      btn = document.createElement("button");
      btn.className = "ytp-button yta-btn";
      btn.title = "Ambient background";
      btn.setAttribute("aria-label", "Ambient background settings");
      btn.innerHTML =
        '<svg viewBox="0 0 24 24" width="100%" height="100%"><g fill="none" stroke="currentColor" stroke-width="1.6">' +
        '<rect x="7" y="8.5" width="10" height="7" rx="1.5"/>' +
        '<path d="M4 6.5v11M20 6.5v11M7 5h10M7 19h10" opacity=".55" stroke-linecap="round"/></g></svg>';
      btn.addEventListener("click", (e) => { e.stopPropagation(); togglePanel(); });
      gear.parentElement.insertBefore(btn, gear);
    }
    if (!panel || !panel.isConnected) {
      panel = buildPanel();
      p.appendChild(panel);
    }
  }

  function buildPanel() {
    const el = document.createElement("div");
    el.className = "yta-panel";
    el.hidden = true;
    el.innerHTML = `
      <div class="yta-row yta-head"><span>Ambient background</span>
        <label class="yta-switch"><input type="checkbox" data-k="enabled"><i></i></label></div>
      <label class="yta-row yta-range"><span>Blur</span><input type="range" min="10" max="120" data-k="blur"><b></b></label>
      <label class="yta-row yta-range"><span>Glow intensity</span><input type="range" min="10" max="100" data-k="intensity"><b></b></label>
      <label class="yta-row yta-range"><span>Glow size</span><input type="range" min="0" max="100" data-k="size"><b></b></label>
      <div class="yta-row"><span>Colour mode</span>
        <div class="yta-seg"><button data-mode="auto">Auto</button><button data-mode="manual">Manual</button></div></div>
      <label class="yta-row"><span>Manual colour</span><input type="color" data-k="color"></label>
      <div class="yta-note" hidden>Auto colour isn't available for this video (likely DRM protected). Using manual colour.</div>
      <div class="yta-credit">by <a href="https://github.com/krit-gupta-dev" target="_blank" rel="noopener noreferrer">Krit Gupta</a></div>`;
    // Keep clicks/keys inside the panel from controlling the player.
    ["click", "mousedown", "dblclick", "keydown", "wheel"].forEach((t) =>
      el.addEventListener(t, (e) => e.stopPropagation()));
    el.querySelectorAll("input[data-k]").forEach((inp) => {
      const k = inp.dataset.k;
      inp.addEventListener("input", () => {
        const v = inp.type === "checkbox" ? inp.checked : inp.type === "range" ? Number(inp.value) : inp.value;
        update({ [k]: v });
      });
    });
    el.querySelectorAll("[data-mode]").forEach((b) =>
      b.addEventListener("click", () => update({ mode: b.dataset.mode })));
    return el;
  }

  function togglePanel(force) {
    if (!panel) return;
    panel.hidden = force !== undefined ? !force : !panel.hidden;
    if (!panel.hidden) updatePanelUI();
  }

  document.addEventListener("click", (e) => {
    if (panel && !panel.hidden && !panel.contains(e.target) && e.target !== btn) togglePanel(false);
  }, true);

  function updatePanelUI() {
    if (!panel) return;
    panel.querySelectorAll("input[data-k]").forEach((inp) => {
      const v = settings[inp.dataset.k];
      if (inp.type === "checkbox") inp.checked = !!v;
      else if (document.activeElement !== inp) inp.value = v;
      const out = inp.nextElementSibling;
      if (out && out.tagName === "B") out.textContent = inp.dataset.k === "blur" ? v + "px" : v + "%";
    });
    panel.querySelectorAll("[data-mode]").forEach((b) =>
      b.classList.toggle("on", b.dataset.mode === settings.mode));
    panel.querySelector(".yta-note").hidden = !(autoBlocked && settings.mode === "auto");
    panel.classList.toggle("yta-off", !settings.enabled);
  }

  function update(partial) {
    Object.assign(settings, partial);
    applyStyle();
    refresh();
    S.save(partial);
  }

  /* ---------- Events ---------- */
  S.onChange((changes) => { Object.assign(settings, changes); applyStyle(); refresh(); });
  document.addEventListener("yt-navigate-finish", () => { autoBlocked = false; blackFrames = 0; setTimeout(refresh, 200); });
  document.addEventListener("fullscreenchange", () => setTimeout(placeLayer, 50));
  document.addEventListener("visibilitychange", () => (document.hidden ? stop() : refresh()));
  // Theater toggle changes the attribute on ytd-watch-flexy
  new MutationObserver(() => placeLayer()).observe(document.documentElement, {
    subtree: true, attributes: true, attributeFilter: ["theater"]
  });
  document.addEventListener("play", (e) => {
    if (e.target && e.target.classList && e.target.classList.contains("html5-main-video")) {
      video = e.target; refresh();
    }
  }, true);

  S.load().then((s) => { settings = s; refresh(); });
})();
