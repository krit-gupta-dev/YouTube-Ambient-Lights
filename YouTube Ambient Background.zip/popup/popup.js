(function () {
  "use strict";
  const S = window.YTAmbientSettings;
  const $ = (id) => document.getElementById(id);
  const ranges = ["blur", "intensity", "size"];

  function render(s) {
    $("enabled").checked = !!s.enabled;
    $("controls").classList.toggle("off", !s.enabled);
    ranges.forEach((k) => {
      if (document.activeElement !== $(k)) $(k).value = s[k];
      $(k + "-v").textContent = k === "blur" ? s[k] + "px" : s[k] + "%";
    });
    $("color").value = s.color;
    document.querySelectorAll("[data-mode]").forEach((b) =>
      b.classList.toggle("on", b.dataset.mode === s.mode));
  }

  let state;
  function set(partial) {
    Object.assign(state, partial);
    render(state);
    S.save(partial);
  }

  $("dev").addEventListener("click", (e) => {
    e.preventDefault();
    S.api.tabs.create({ url: "https://github.com/krit-gupta-dev" });
    window.close();
  });

  S.load().then((s) => {
    state = s;
    render(state);
    $("enabled").addEventListener("change", (e) => set({ enabled: e.target.checked }));
    ranges.forEach((k) => $(k).addEventListener("input", (e) => set({ [k]: Number(e.target.value) })));
    $("color").addEventListener("input", (e) => set({ color: e.target.value }));
    document.querySelectorAll("[data-mode]").forEach((b) =>
      b.addEventListener("click", () => set({ mode: b.dataset.mode })));
    S.onChange((c) => { Object.assign(state, c); render(state); });
  });
})();
