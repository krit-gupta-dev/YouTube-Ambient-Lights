# YouTube Ambient Background (Firefox)

A lightweight Firefox extension that makes the area behind the YouTube player glow with soft, blurred colours from the video that is playing.

- Manifest V3, plain HTML / CSS / vanilla JavaScript
- Only permission: `storage` (to remember your settings)
- Runs only on `youtube.com`
- No accounts, analytics, network requests or external services

## Features

- Ambient glow sampled from the playing video (Auto mode)
- Manual colour mode with a colour picker
- Blur intensity, glow intensity and glow size sliders
- On/off toggle
- Settings button in the YouTube player controls (next to the gear) and the same controls in the toolbar popup
- Settings are saved and kept after restarting Firefox
- Works in normal, theater and fullscreen modes

## Install (temporary, for testing)

1. Open Firefox and go to `about:debugging#/runtime/this-firefox`.
2. Click **Load Temporary Add-on…**.
3. Select the `manifest.json` file inside this folder.
4. Open any YouTube video. Use the new ambient button next to the player's gear icon, or the toolbar icon.

Temporary add-ons are removed when Firefox closes. Settings are kept for the next time you load it (same add-on ID).

> Firefox 109+ is required. In MV3, Firefox may ask you to allow the extension on youtube.com: click the puzzle icon in the toolbar → the extension → **Always allow on www.youtube.com**.

## How the colour sampling works

Every ~100 ms while the video plays, the current frame is drawn into a tiny 16×9 canvas. That canvas is stretched and blurred behind the player with CSS. Because the canvas is only displayed, not read back, this works for normal YouTube videos. Sampling pauses when the video is paused, when the tab is hidden or when the effect is off, so playback isn't affected.

**Limitation:** DRM-protected videos (some films, rentals and premium content) appear black when drawn to a canvas. The extension notices this and switches to your manual colour, showing a short note in the player panel. Manual mode always works.

## Files

```
manifest.json      extension manifest (MV3)
settings.js        shared settings defaults + storage helpers
content.js         glow layer, sampling loop, in-player panel
content.css        glow and panel styles
popup/             toolbar popup (HTML/CSS/JS)
icons/             extension icons
```

## Developer

Krit Gupta — https://github.com/krit-gupta-dev

## License

MIT License

Copyright (c) 2026 Krit Gupta

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
