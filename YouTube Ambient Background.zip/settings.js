/* Shared settings helpers (used by content script and popup). */
(function (root) {
  "use strict";
  const api = typeof browser !== "undefined" ? browser : chrome;

  const DEFAULTS = Object.freeze({
    enabled: true,
    blur: 60,        // px, 10-120
    intensity: 70,   // %, 10-100
    size: 40,        // %, 0-100 (how far the glow spreads)
    mode: "auto",    // "auto" | "manual"
    color: "#ff3d3d"
  });

  async function load() {
    try {
      const data = await api.storage.local.get(DEFAULTS);
      return Object.assign({}, DEFAULTS, data);
    } catch (e) {
      return Object.assign({}, DEFAULTS);
    }
  }

  function save(partial) {
    return api.storage.local.set(partial);
  }

  function onChange(cb) {
    api.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      const out = {};
      for (const k of Object.keys(changes)) {
        if (k in DEFAULTS) out[k] = changes[k].newValue;
      }
      if (Object.keys(out).length) cb(out);
    });
  }

  root.YTAmbientSettings = { DEFAULTS, load, save, onChange, api };
})(typeof window !== "undefined" ? window : this);
